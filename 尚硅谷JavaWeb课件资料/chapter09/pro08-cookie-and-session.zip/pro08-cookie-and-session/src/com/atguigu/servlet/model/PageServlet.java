package com.atguigu.servlet.model;

import com.atguigu.servlet.base.ModelBaseServlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class PageServlet extends ModelBaseServlet {
    protected void toPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String pageName = request.getParameter("pageName");

        String viewName = "page-" + pageName;

        processTemplate(viewName, request, response);

    }
}
